export class SharedProps {
  public static designerUrl = 'https://infinica-training.cloud.infinica.com/infinica-business-designer';
}
